export enum BitWidth {
  WIDTH8 = 0,
  WIDTH16 = 1,
  WIDTH32 = 2,
  WIDTH64 = 3,
}